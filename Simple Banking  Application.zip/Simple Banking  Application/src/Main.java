import java.util.Scanner;
import java.util.ArrayList;

public class Main {

    static class Account { //This class represent an account
        String accountNumber;
        String accountHolder;
        double balance;

        Account(String accountNumber, String accountHolder){
            this.accountNumber = accountNumber;
            this.accountHolder = accountHolder;
            this.balance = 0.0;
        }
    }

    //List is created to store account and its details
    static ArrayList<Account> accounts = new ArrayList<>();
    static Scanner sc = new Scanner(System.in);

    static void createAccount(){ //Used to create  a new account
        System.out.println("Enter account number: ");
        String accountNumber = sc.nextLine();
        System.out.println("Enter Account holder's name: ");
        String accountHolder = sc.nextLine();

        //checking if there is existing account number.
        for(Account acc : accounts) {
            if(acc.accountNumber.equals(accountNumber)){
                System.out.println("Account already exists with this number.");
                return;
            }
        }

        //Adding new account
        accounts.add(new Account(accountNumber, accountHolder));
        System.out.println("Account Created Successfully !");
    }

    static void depositMoney(){//if the user wants to deposit money
        System.out.println("Enter account number:");
        String accountNumber = sc.nextLine();

        //Find the account
        for(Account acc: accounts){
            if(acc.accountNumber.equals(accountNumber)){
                System.out.println("Enter amount to deposit: ");
                double amount = sc.nextDouble();
                sc.nextLine();
                if(amount>0){
                    acc.balance+=amount;
                    System.out.println("Deposited successfully !!!\nCurrent balance: "+acc.balance);
                }
                else{
                    System.out.println("Amount should be greater than zero.");
                }
                return;
            }
        }

        System.out.println("Account not found!");
    }

    static void withdrawMoney(){
        System.out.println("Enter account number: ");
        String accountNumber = sc.nextLine();

        //Check account availability
        for(Account acc: accounts){
            if(acc.accountNumber.equals(accountNumber)){
                System.out.println("Enter amount to withdraw:");
                double amount = sc.nextDouble();
                sc.nextLine();
                if(amount>0 && amount<=acc.balance){
                    acc.balance-=amount;
                    System.out.println("Withdrawal Successful !!!\nCurrent Balance: "+acc.balance);
                }
                else if(amount<0){
                    System.out.println("Invalid Amount!");
                }
                else{
                    System.out.println("Insufficient balance !!!");
                }
                return;
            }
        }

        System.out.println("Account not found!");
    }

    static void checkBalance() {//To check the balance
        System.out.println("Enter account number:");
        String accountNumber = sc.nextLine();

        //Find the account
        for(Account acc : accounts) {
            if(acc.accountNumber.equals(accountNumber)){
                System.out.println("Account Holder: "+acc.accountHolder);
                System.out.println("Account Balance: "+acc.balance);
                return;
            }
        }

        System.out.println("Account not found!");
    }

    public static void main(String[] args) {
        int choice;
        boolean loop = true;

        while(loop){

            //Display Menu
            System.out.println("\n---Banking Options---");
            System.out.println("1. Create an Account.");
            System.out.println("2. Deposit Money.");
            System.out.println("3. Withdraw Money.");
            System.out.println("4. Check Balance.");
            System.out.println("5. Exit");

            System.out.println("Enter your choice: ");
            choice = sc.nextInt();
            sc.nextLine();

            switch(choice){

                case 1: //to create an account
                    createAccount();
                    break;

                case 2: //to deposit money into account
                    depositMoney();
                    break;

                case 3: //to withdraw amount
                    withdrawMoney();
                    break;

                case 4: //to check balance
                    checkBalance();
                    break;

                case 5: //if they want to exit
                    System.out.println("Are you sure to exit? (yes-1/no-0)");
                    int exit = sc.nextInt();
                    if(exit == 1){
                        System.out.println("Thank you for using the Banking Application!");
                        loop = false;
                    }
                    break;

                default:
                    System.out.println("Invalid choice !!!");
                    break;
            }

        }

    }
}